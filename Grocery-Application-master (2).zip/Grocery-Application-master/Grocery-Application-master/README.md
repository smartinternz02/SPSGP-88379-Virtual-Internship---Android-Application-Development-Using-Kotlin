# GroceryApplication
Hi, I am Mahendra Lohar.
This Project Is a part of Virtual Internship - Android Application Development Using Kotlin.

As we can't remember everything, users frequently forget to buy the things they want to buy. However, with the assistance of this app, you can make a list of the groceries you intend to buy so that you don't forget anything.


# Screenshot of the Application

## 1) Adding Grocery to the Application
<img width="218" alt="image" src="https://user-images.githubusercontent.com/91696273/189961948-76365f11-33a1-46e4-8757-fe0ccc5bc9b2.png">          <img width="229" alt="image" src="https://user-images.githubusercontent.com/91696273/189962118-1ac9002d-f697-4814-aabb-d30eb0e8f5f0.png">  

## 2) Grocery got added
<img width="227" alt="image" src="https://user-images.githubusercontent.com/91696273/189962380-4f598dee-844c-4c28-aa2e-b65e3a25d201.png">   <img width="225" alt="image" src="https://user-images.githubusercontent.com/91696273/189962575-16912f77-6520-4893-a25a-0097853872a2.png">    

## 3) Deletion of Item

<img width="230" alt="image" src="https://user-images.githubusercontent.com/91696273/189962674-dc6446a4-d588-40f7-b0af-8ef47317c814.png">











